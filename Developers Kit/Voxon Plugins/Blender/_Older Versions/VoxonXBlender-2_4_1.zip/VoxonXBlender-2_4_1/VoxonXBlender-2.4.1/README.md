# VoxonXBlender
A Blender add-on for creating recordings or displaying in real-time Blender projects on Voxon volumetric displays.
