from ctypes import c_float, c_uint16, c_uint32, c_char
import numpy as np

# voxieplay commands:
def CmdFrameStart(time):
	cmd = b'F'
	data = bytearray(c_float(time))
	return (cmd + data)

def CmdFrameEnd():
	cmd = b'E'
	return cmd
	
def CmdSetView(aspect):
	cmd = b'v'
	dims_np = np.array((-aspect[0],-aspect[1],-aspect[2],aspect[0],aspect[1],aspect[2]), dtype=np.float16)
	dims_bytes = dims_np.tobytes()
	return (cmd + dims_bytes)

def CmdDrawMeshTex(obj, fill =2 , col = 0xFFFFFFFF, image_name = ""):
	# 64 bit
	if('poltex' not in obj):
		return
		
	if(len(obj['poltex']) >= 1073741824 or len(obj['indices']) >= 1073741824):
		print("Mesh too large, consider splitting into submesh")
		return
	# 32 Bit
	elif(len(image_name) > 0):
		return CmdDrawMeshTex32Bit(obj, fill, col, image_name)
	elif(len(obj['poltex']) >= 32767 or len(obj['indices']) >= 32767):
		return CmdDrawMeshTex32Bit(obj, fill, col, image_name)
	# 16 Bit
	else:
		return CmdDrawMeshTex16Bit(obj, fill, col)
	
def CmdDrawMeshTex32Bit(obj, fill =2 , col = 0xFFFFFFFF, image_name = ""):
	# timer_start = time.process_time()
	cmd = b'O'
	
	vertNo = len(obj['poltex'])
	cmd += image_name.encode('ascii')
	cmd += bytearray(c_char(0))
	cmd += bytearray(c_uint32(vertNo)) # vertex count
	
	for vert in obj['poltex']:
		vert_np = np.array(vert[0:5], dtype=np.float16)
		vert_bytes = vert_np.tobytes()
		cmd += vert_bytes + bytearray(c_uint32(int(vert[5])))

	# confirm sizes / bit positions are correct
	# ind_timer = time.process_time()
	if(obj['recalc']):
		indNo = len(obj['indices'])
		cmd_indices = b''
		
		cmd_indices += bytearray(c_uint32(indNo)) # vertex count
			
		for index in obj['indices']:
			cmd_indices += bytearray(c_uint32(index))
			
		obj['cmd_indices'] = cmd_indices

	cmd += obj['cmd_indices']
	
	# Flags
	cmd += bytearray(c_char(fill))
	
	# Color
	cmd += bytearray(c_uint32(col))
	# M, Vert# (uint16), Verts [point3d, uint32], index# (uint16), indices[uint16], flags (unint8), col (uint32)
	
	#net_writef('M',"u2{h3u4}u2{u2}u1u4"		 ,vtn,&vt[0].x,i,&vt[0].col,i,meshn,&mesh[0],sizeof(mesh[0]),flags,col); //voxie_drawmeshtex no texture (NOTE: (flags&(1<<3) != 0) unsupported))
	#net_writef('M',"u2{h3u4}u2{u2}u1u4"			 ,i,&vt[0].x,24,&vt[0].col,24,j,mesh,4,2,0x404040); //voxie_drawmeshtex
	# print("\tBuild Mesh: {} ms".format((time.process_time() - timer_start) * 1000))
	return cmd

def CmdDrawMeshTex16Bit(obj, fill =2 , col = 0xFFFFFFFF):
	# timer_start = time.process_time()
	cmd = b'M'
	
	vertNo = len(obj['poltex'])
	# TODO V2 (Check Conversions)
	cmd += bytearray(c_uint16(vertNo)) # vertex count
	
	for vert in obj['poltex']:
		vert_np = np.array(vert[0:3], dtype=np.float16)
		vert_bytes = vert_np.tobytes()
		cmd += vert_bytes + bytearray(c_uint32(int(vert[5])))

	# confirm sizes / bit positions are correct
	# ind_timer = time.process_time()
	if(obj['recalc']):
		indNo = len(obj['indices'])
		cmd_indices = b''
	
		# TODO V2 (Check Conversions)
		cmd_indices += bytearray(c_uint16(indNo)) # vertex count
			
		for index in obj['indices']:
			cmd_indices += bytearray(c_uint16(index))
			
		obj['cmd_indices'] = cmd_indices

	cmd += obj['cmd_indices']
	
	# Flags
	cmd += bytearray(c_char(fill))
	
	# Color
	cmd += bytearray(c_uint32(col))
	# M, Vert# (uint16), Verts [point3d, uint32], index# (uint16), indices[uint16], flags (unint8), col (uint32)
	
	#net_writef('M',"u2{h3u4}u2{u2}u1u4"		 ,vtn,&vt[0].x,i,&vt[0].col,i,meshn,&mesh[0],sizeof(mesh[0]),flags,col); //voxie_drawmeshtex no texture (NOTE: (flags&(1<<3) != 0) unsupported))
	#net_writef('M',"u2{h3u4}u2{u2}u1u4"			 ,i,&vt[0].x,24,&vt[0].col,24,j,mesh,4,2,0x404040); //voxie_drawmeshtex
	# print("\tBuild Mesh: {} ms".format((time.process_time() - timer_start) * 1000))
	return cmd

def CmdDrawBox(coords, fill, col):
	cmd = b'B'
	coords_np = np.array(coords, dtype=np.float16)
	coords_bytes = coords_np.tobytes()
	return cmd + coords_bytes + bytearray(c_char(fill)) + bytearray(c_uint32(col))

def CmdInitialise():
	init = (b"KenSVXBX:-P" + bytes(1))
	return (init)

def CmdRequestInfo():
	cmd = b'a'
	return cmd

def CmdSendFile(filepath, name):
	file = open(filepath, "rb")
	data = file.read()
	file.close()

	cmd = b'x' + name.encode('ascii') + b'\x00' + bytearray(c_uint32(len(data))) + data
	return cmd