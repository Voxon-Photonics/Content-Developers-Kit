'''
Voxon Blender Plugin.
Originally by Ben Weatherall Jan 2021 for Voxon Photonics 
Updated and Maintained by Matthew Vecchio for Voxon Phtonics 
Updated 2023 by Ryan Silvermanto use BigPak library and with more features
'''

bl_info = {
	"name": "Voxon x Blender Connect v2.2",
	"blender": (3, 0, 0),
	"category": "Object",
}

from bpy.types import(
		Panel,
		Operator,
		PropertyGroup
		)

from bpy.props import(
		StringProperty,
		BoolProperty,
		PointerProperty,
		EnumProperty,
		FloatVectorProperty,
		IntProperty
		)

import bpy
import mathutils
from bpy.app.handlers import persistent

import time
from .bigpak import BigPak
from .voxieplay import *
import time, functools
import struct

CONNECTION = None
REGISTERED_LOOP = None
	
# Core functionality
class VoxonCast():
	def __init__(self, HOST, PORT = 8080):
		self.host = HOST
		self.port = PORT
		self.msg = CmdRequestInfo()
		self.start_time = time.time()
		self.remote_time = 0.0
		
	
	def connect(self):
		try:
			if(self.bigpak):
				self.bigpak.close()
		except Exception:
			pass
		try:
			self.bigpak = BigPak(self.host, self.port, recv_port = 8090)
			for obj in bpy.data.objects:
				obj['imloaded'] = False
			return True
		except Exception as e:
			print(e)
			return False
		
	def disconnect(self):
		print("Disconnecting from host")
		if(self.bigpak):
			try:
				self.bigpak.close()
			except Exception:
				print("Failed to disconnect")
				pass # avoid being stuck if port was already disconnected
			
		scene = bpy.context.scene.voxon_properties
		scene.connected = False
			
	def loop(self):
		if(self.bigpak == None):
			return 0.1
			
		if((time.time() - self.start_time) < self.remote_time):
			return 0.01
		
		dps = bpy.context.evaluated_depsgraph_get()
		
		# Start Frame
		self.msg += CmdFrameStart(time.time() - self.start_time)
		# Set ViewPort
		aspect = bpy.context.scene.voxon_properties.aspect
		self.msg += CmdSetView(aspect)
		
		try:
			matrix_viewbox = bpy.data.objects['VIEWBOX'].matrix_world
			matrix_viewbox = matrix_viewbox.copy()
			matrix_viewbox.invert()
		except KeyError:
			matrix_viewbox = mathutils.Matrix() # Identity Matrix

		# Get Objects
		for obj in bpy.data.objects:
			if obj.type != 'MESH':
				continue
			if obj.name == 'VIEWBOX':
				continue
			if obj.hide_render:
				continue
			
			try:
				object_eval = obj.evaluated_get(dps) # get mesh with modifiers
				mesh = object_eval.to_mesh()
				mesh.transform(obj.matrix_world)
				mesh.transform(matrix_viewbox)

				# Material Properties
				color = 0xFFFFFF
				image_texture = False
				vertex_color = False
				image_name = ''
				fillmode = 2
				
				if(len(mesh.materials) > 0):
					material = mesh.materials[0]
					if material.use_nodes:
						output_node = material.node_tree.get_output_node('ALL')
						if output_node != None:
							shader_node = output_node.inputs[0].links[0].from_node
							shader_node_type = shader_node.bl_idname
							if shader_node_type == 'ShaderNodeBsdfPrincipled' or shader_node_type == 'ShaderNodeBsdfDiffuse':
								if shader_node.inputs[0].is_linked:
									image_node = shader_node.inputs[0].links[0].from_node
									if image_node.bl_idname == 'ShaderNodeTexImage':
										color = 0x404040
										image_texture = True
										image = image_node.image
										image_name = image.name
										if 'imloaded' not in obj:
											obj['imloaded'] = False
										if not obj['imloaded']:
											image = image_node.image
											self.msg += CmdSendFile(image.filepath, image_name)
											obj['imloaded'] = True
									elif image_node.bl_idname == 'ShaderNodeVertexColor':
										vertex_color = True
									else:
										continue
								else:
									colours = shader_node.inputs[0].default_value
									color = int(colours[2] * 255)
									color += int(colours[1] * 255) << 8
									color += int(colours[0] * 255) << 16
							else:
								continue
						else:
							continue
					else:
						colours = material.diffuse_color
						color = int(colours[2] * 255)
						color += int(colours[1] * 255) << 8
						color += int(colours[0] * 255) << 16

					fillmode = int(mesh.materials[0].fillmode)
					if vertex_color:
						fillmode += 16
				
				verts = mesh.vertices
				pols = []

				if image_texture:
					uvs = mesh.uv_layers.active.uv
					for i in range(len(verts)):
						vert = verts[i]
						uv = uvs[i].vector
						pols.append((-vert.co.x, vert.co.y, -vert.co.z, uv[0], 1 - uv[1], 0xFFFFFF))
				elif vertex_color:
					vertex_colors = mesh.color_attributes.active_color.data
					for i in range(len(verts)):
						vert = verts[i]
						vcolours = vertex_colors[i].color
						vcolor = int(vcolours[2] * 255)
						vcolor += int(vcolours[1] * 255) << 8
						vcolor += int(vcolours[0] * 255) << 16
						pols.append((-vert.co.x, vert.co.y, -vert.co.z, 0, 0, vcolor))
				else:
					for vert in verts:
						pols.append((-vert.co.x, vert.co.y, -vert.co.z, 0,0,0xFFFFFF))

				obj['recalc'] = False
				
				if('poltex' not in obj or len(pols) != len(obj['poltex'])):
					obj['recalc'] = True
					
				obj['poltex'] = pols
			
				recalc_indices = True
				
				if('edgeCount' not in obj or obj['edgeCount'] != len(mesh.edges)):
					edge_timer = time.process_time()
					
					obj['edgeCount'] = len(mesh.edges)
					indices = []
					polys = mesh.polygons
					for poly in polys:
						for loop_index in range(poly.loop_start, poly.loop_start + poly.loop_total):
							indices.append(mesh.loops[loop_index].vertex_index)
						indices.append(-1)
					
					obj['indices'] = indices
					print('calculate edges: {}'.format((time.process_time() - edge_timer)*1000))
				else:
					recalc_indices = False
					
				obj['recalc'] = obj['recalc'] or recalc_indices
						
				self.msg += CmdDrawMeshTex(obj, fillmode, color, image_name)

				# object_eval.to_mesh_clear()
			except Exception as e:
				print(e)
				self.msg = b''
				self.disconnect()
				
				global REGISTERED_LOOP
				if(bpy.app.timers.is_registered(REGISTERED_LOOP)):
					bpy.app.timers.unregister(REGISTERED_LOOP)
				return None
		
		if(bpy.context.scene.voxon_properties.show_viewbox):
			aspect = bpy.context.scene.voxon_properties.aspect
			self.msg += CmdDrawBox((-aspect[0],-aspect[1],-aspect[2],aspect[0],aspect[1],aspect[2]),1,0xffffff)		
		self.msg += CmdFrameEnd()

		# Get Response')
		try:
			self.bigpak.send_msg(self.msg)
			self.msg = b''
			
			self.ProcessResponse()
				
		except BigPak.error as e:
			# if e.errno != 55: # For Mac
			print(e)
			self.disconnect()
			if(bpy.app.timers.is_registered(REGISTERED_LOOP)):
				bpy.app.timers.unregister(REGISTERED_LOOP)
			self.bigpak = None
			return None
		except Exception as e:
			print(e)
			
		# print("Process time: {}".format((time.process_time()-timer_start)*1000))
		
		return 0.01

	# Primarily to get aspect ratio info	
	def ProcessResponse(self):
		gen_viewbox = bpy.context.scene.voxon_properties.gen_viewbox
		if gen_viewbox:
			try:
				response = self.bigpak.recv_msg()
			except BigPak.error as e:
				if e.errno != 11 and e.errno != 35:
					raise e
				return
			# Process Data
			response_len = len(response)
			
			try:
				if response_len >= 4 and struct.unpack('I', response[0:4])[0] == 0x6c527443:
					i = 4
					while(i < response_len):
						cmd = struct.unpack('B', response[i:i + 1])[0]
						if cmd == 0:
							break
						elif cmd == 160:
							i += 1
							aspect = tuple(struct.unpack('fff', response[i:i+12]))
							i += 12
							bpy.context.scene.voxon_properties.aspect = aspect
							print("Aspect ratio: "+ str(aspect))
							make_viewbox(aspect)
							bpy.context.scene.voxon_properties.gen_viewbox = False
			except Exception:
				print(b'Invalid response recieved: ' + response)

def make_viewbox(aspect):
	try:
		bpy.ops.object.mode_set(mode='OBJECT')
		bpy.ops.object.select_all(action='DESELECT')
		bpy.data.objects['VIEWBOX'].select_set(True)

		# Get rid of any transformations and reapply at the end
		matrix_viewbox = bpy.data.objects['VIEWBOX'].matrix_world
		matrix_viewbox_copy = matrix_viewbox.copy()
		matrix_viewbox.identity()

		bpy.ops.object.mode_set(mode='EDIT')
		bpy.ops.mesh.primitive_cube_add(scale = aspect)
		bpy.ops.mesh.select_all(action='INVERT')
		bpy.ops.mesh.delete()
		bpy.ops.object.mode_set(mode='OBJECT')

		bpy.data.objects['VIEWBOX'].matrix_world = matrix_viewbox_copy
	except Exception:
		bpy.ops.mesh.primitive_cube_add(scale = aspect)
		viewbox = bpy.context.selected_objects[0]
		viewbox.show_axis = True
		viewbox.display_type = 'WIRE'
		viewbox.name = 'VIEWBOX'


class VoxonRenderingPanel(Panel):
	"""Creates a Panel in the scene context of the properties editor"""
	bl_label = "Voxon Rendering"
	bl_idname = "RENDER_PT_layout"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = "render"

	def draw(self, context):
		layout = self.layout

		scene = context.scene.voxon_properties 

		row = layout.row()
		row.label(text='Connect to Voxon Device')
		row = layout.row()
		row.prop(scene, "ip_address")
		row = layout.row()
		row.prop(scene, "gen_viewbox")
		row = layout.row()
		row.prop(scene, "show_viewbox")

		row = layout.row(align=True)
		sub = row.row()
		
		if(scene.connected):
			sub.operator("voxon.active_connection", text="Disconnect")
		else:
			sub.operator("voxon.active_connection", text="Connect")
		
		row = layout.separator()
		row = layout.row()
		row.label(text='Generate Viewbox')
		row = layout.row()
		row.prop(scene, "aspect")
		row = layout.row(align=True)
		sub = row.row()
		sub.operator("voxon.viewbox", text="Generate Viewbox")

class ViewboxWrapper(Operator):
	bl_idname = "voxon.viewbox"
	bl_label = "Make Viewbox"

	def execute(self, context):
		aspect = bpy.context.scene.voxon_properties.aspect
		make_viewbox(aspect)
		return {'FINISHED'}

# This class is the actual dialog that pops up to create the cube
class NetworkConnectionDialog(Operator):
	bl_idname = "voxon.active_connection"
	bl_label = "VX Hardware Address"
	
	# This is the method that is called when the ok button is pressed
	# which is what calls the AddCube() method 
	def execute(self, context):
		global CONNECTION
		global REGISTERED_LOOP
		
		scene = context.scene.voxon_properties
		if(scene.connected):
			if(CONNECTION):
				CONNECTION.disconnect()
			if(bpy.app.timers.is_registered(REGISTERED_LOOP)):
				bpy.app.timers.unregister(REGISTERED_LOOP)
			scene.connected = False
			return {'FINISHED'}
		else:
			self.report({'INFO'}, "Connecting to {}".format(scene.ip_address, scene))
			CONNECTION = VoxonCast(scene.ip_address)
			scene.connected = CONNECTION.connect()			
			if(scene.connected):
				REGISTERED_LOOP = functools.partial(CONNECTION.loop)
				bpy.app.timers.register(REGISTERED_LOOP)
				print("Is Loop registered? {}".format(bpy.app.timers.is_registered(REGISTERED_LOOP)))
			return {'FINISHED'}
		
# your properties here
class addon_Properties(PropertyGroup):
	ip_address: StringProperty(
		name = "IP Address",
		description="IP of Voxon Hardware",
		default = "127.0.0.1"
		)
	gen_viewbox: BoolProperty(
		name = "Auto-generate Viewbox",
		description = "Generate viewbox based on aspect sent by the Voxon device",
		default = True
	)
	connected: BoolProperty(
		name = "Connected",
		default = False
		)
	show_viewbox: BoolProperty(
		name = "Render Viewbox",
		default = False
		)
	aspect: FloatVectorProperty(
		name = "Aspect Ratio",
		size = 3,
		default = (1.0,0.67,.36)
	)


class Fillmode_Panel(Panel):
    bl_idname = "PANEL_PT_fillmode"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_label = "Fill Mode"
    bl_context = "material"

    def draw(self, context):
        _material = context.material or bpy.data.materials.new('Material')

        layout = self.layout
        layout.prop(_material, "fillmode")

# Blender functions
@persistent	
def load_pre_handler(dummy):
	print("Disconnecting connection")
	scene = bpy.context.scene.voxon_properties
	if(scene.connected):
		if(CONNECTION):
			CONNECTION.disconnect()
		if(bpy.app.timers.is_registered(REGISTERED_LOOP)):
			bpy.app.timers.unregister(REGISTERED_LOOP)
		scene.connected = False
		time.sleep(0.1)
	return {'FINISHED'}


'''
def object_interaction(scene):
	if hasattr(bpy.context, 'active_object') and bpy.context.active_object != None:
		active_obj = bpy.context.active_object
		print(dir(active_obj.data))
		if active_obj.is_modified or active_obj.data.is_evaluated or active_obj.is_updated_data:
			print("Active: {}".format(active_obj.name_full))
			bpy.context.active_object['REFRESH'] = True
'''
	
def register():

	bpy.utils.register_class(VoxonRenderingPanel)
	bpy.utils.register_class(NetworkConnectionDialog)
	bpy.utils.register_class(ViewboxWrapper)
	bpy.utils.register_class(addon_Properties)
	bpy.utils.register_class(Fillmode_Panel)
	
	try:
		bpy.types.Material.fillmode = EnumProperty(
			name = "Fill Mode",
			description = "",
			default = '2',
			items = [
				('0', "Dot", ""),
				('1', "Line", ""),
				('2', "Surface", ""),
				('3', "Solid", "")
        	]
    	)
	except ValueError:
		pass # fillmode has already been set-up
	bpy.types.Scene.voxon_properties = PointerProperty(type=addon_Properties)

	bpy.app.handlers.load_pre.append(load_pre_handler)
	# bpy.app.handlers.depsgraph_update_pre.append(object_interaction)
	
	
def unregister():
	if(bpy.app.timers.is_registered(REGISTERED_LOOP)):	
		bpy.app.timers.unregister(REGISTERED_LOOP)
	
	bpy.utils.unregister_class(VoxonRenderingPanel)
	bpy.utils.unregister_class(NetworkConnectionDialog)
	bpy.utils.unregister_class(ViewboxWrapper)
	bpy.utils.unregister_class(addon_Properties)
	bpy.utils.unregister_class(Fillmode_Panel)
	
	del bpy.types.Material.fillmode
	del bpy.types.Scene.voxon_properties
	
	bpy.app.handlers.load_pre.remove(load_pre_handler)
	
	# bpy.app.handlers.depsgraph_update_pre.clear()